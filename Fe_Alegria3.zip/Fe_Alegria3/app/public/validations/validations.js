$(document).ready(function(){


function validateField(){
  $('#BtnActua').on('click', function(){
        xajax_SearchCedula(xajax.getFormValues('form'));
    })   
}


















});