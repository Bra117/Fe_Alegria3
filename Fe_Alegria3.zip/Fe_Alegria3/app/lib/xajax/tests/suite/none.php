<?
	require_once("./options.inc.php");
	require_once('./testScriptPlugin.inc.php');


	$objTestScriptPlugin->printHeader($xajax, "Xajax Test Suite");
?>
		Please select the xajax options above, then select a test page from the drop down.
<?

	$objTestScriptPlugin->printFooter();	
