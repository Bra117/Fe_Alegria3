
<table  class='myTable' border='1px solid #000' style='width:100%;margin:0px;'>
      <tr><th colspan="8">DATOS DE PAGO DE IMPUESTO</th></tr>

        <tr>
            <td colspan="3">BANCO</td>
            <td colspan="5"></td>
        </tr>
         <tr>
            <td colspan="4">N° TRANSFERENCIA</td>
            <td colspan="4">MONTO BS</td>
            
        </tr>
           <tr>
            <td colspan="4">1</td>
            <td colspan="4"> 1</td>
            
        </tr>
     

