<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title></title>
         <!-- Tempusdominus Bootstrap 4 -->
      <link rel="stylesheet" href="<?php echo APP;?>app/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">


    <style>
        
                @page {
                    margin: 100px 55px;
                } 

                header {
                    position: fixed;
                    top: -60px;
                    left: 0px;
                    right: 0px;
                    height: 50px;
                    /*background-color: #03a9f4;*/
                    color: black;
                    text-align: center;
                    line-height: 35px;
                }

                footer {
                    position: fixed; 
                    bottom: -30px; 
                    left: 0px; 
                    right: 0px;
                    height: 60px; 

                    /*background-color: #03a9f4;*/
                    color: black;
                    text-align: center;
                    line-height: 1px;
                }

              .text-center{text-align: center;}
              .text-justify {text-align: justify;}

          .myTable {
            width: 100%;
            max-width: 100%;
            margin-bottom: 20px;
            border-spacing: 0;
            border-collapse: collapse;
            border: 1px;
            font-size:9px;
          }

    </style>


    </head>
<body>
    <header>
       Unidad Educativa Fe y Alegría "Andy Aparicio"
       
    </header>
    <div id = "id" class="pie-form" >
            <img  id = "sms" class = "img" src = "Fe_Alegria3/app/public/images/fondo_negro.jpg"/>           
        </div>
    <br>
    <p>Senor padre de familia y/o representante del <strong>ESTUDIANTE: </strong><u><?php echo "nombre del estudiante, "?> </u>ANO Y SECCION: <u><?php echo "ano y seccion del estudiante"?></u></p>
</body>