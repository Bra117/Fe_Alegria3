
    <!--DATOS DE LA EMPRESA-->
    <tr>
        <th colspan="11" ><center class="colorCelda">DATOS DE LA EMPRESA</center></th>
    </tr>
    <tr>
        <th colspan="2"><center class="colorCelda">RAZÓN SOCIAL</center></th>
        <td colspan="9"><?php echo $row['razon_social'] ?></td>
    </tr>
    <tr>
        <th colspan="2"><center class="colorCelda">RIF</center></th>
        <td colspan="9"><?php echo $row['rif'] ?></td>
    </tr>
    <tr>
        <th colspan="2"><center class="colorCelda">DIRECCIÓN</center></th>
        <td colspan="9"><?php echo $row['direccion_empresa'] ?></td>
    </tr>
    <tr>
        <th colspan="2"><center class="colorCelda">PERMISO DE FUNCIONAMIENTO</center></th>
        <td colspan="9"><?php echo $row['permiso'] ?></td>
    </tr>