
    <!--TOTAL CANTIDAD MERCANCIA-->
    <tr>
        <th colspan="8" ><center class="colorCelda">TOTAL CANTIDAD</center></th>
    </tr>
    <tr>
        <th colspan="3" ><center class="colorCelda">PRESENTACIÓN</center></th>
        <th colspan="2" ><center class="colorCelda">CANTIDAD</center></th>
        <th colspan="3" ><center class="colorCelda">UNIDAD DE MEDIDA</center></th>
    </tr>
    <tr>
         <td colspan="3" ><center class="colorCelda">PRESENTACIÓN</center></td>
        <td colspan="2" ><center class="colorCelda">CANTIDAD</center></td>
        <td colspan="3" ><center class="colorCelda">UNIDAD DE MEDIDA</center></td>
    </tr>



</table>