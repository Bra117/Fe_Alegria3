<!--DATOS DE LA FIRMA  ELECTRÓNICA-->
         <tr>
            <td colspan="8">SE HACE CONSTAR QUE NO SE OCASIONARON DAÑOS MATERIALES NI MORALES COMO CONSECUENCIA DE ESTA ACTUACION SANITARIA</td>
          
            
        </tr>
         <tr>
            <td colspan="8">DATOS DE (LOS) FUNCIONARIO(S)ACTUANTES POR EL SERVIO AUTÓNOMO DE CONTRALORÍA SANITARIA</td>
          
            
        </tr>
          <tr>
            <td colspan="4">FUNCIONARIO DESIGNADO POR EL SACS:</td>
              <td colspan="4">DATOS DEL REPRESENTANTE ADUANAL AUTORIZADO:</td>
        </tr>

</table>

