<?php
require ('app/plugins/xajax/xajax.inc.php');
  //instanciamos el objeto de la clase xajax
  $xajax = new xajax();
  //Función()
function volver(){
  $obj = new xajaxResponse('UTF-8');
  session_destroy();
  $obj->addRedirect("login");
  return $obj;
}

function showLimitacionEdad(){
    $obj = new xajaxResponse('UTF-8');
    $loginModel = new register_alumnoModel();
    $result = $loginModel->ValidationEdad();
    $html = "";
    //var_dump($result);
    
    $html="<div class='table-responsive';>
      <table id='grid' class='table table-bordered' width='100%'>
        <thead>
          <tr style='background-color: black; color:white;'>
            <th class='text-center' style='width: 6%;'>Nro validacion</th>
            <th class='text-center' style='width: 6%;'>Estatus validacion</th>
            <th class='text-center' style='width: 6%;'>Ano Minimo EStudiante</th>
            <th class='text-center' style='width: 6%;'>Ano Maximo EStudiante</th>
            <th class='text-center' style='width: 6%;'>Editar Materia</th>
        </thead>
        <tbody>";
    for ($i=0; $i < $result['numRows']; $i++) { 
      $agente = pg_fetch_assoc($result['query'], $i);
       //var_dump($agente);

      if ($agente['id_status'] != 1) {
            $html.= '<tr class = text-center>
                <td>'.$agente['id_validacion_edad'].'</td>
                <td style = "color: red;">'.$agente['d_status'].'</td>
                <td>'.$agente['edad_min_estudiante'].'</td>
                <td>'.$agente['edad_max_estudiante'].'</td>
                <td style="width: 10%;">
                    <div class="btn-group">
                        <button type="button" style = "box-shadow: 0px 9px 3px rgba(0,0,0,.2); font-family: "Lato";" class = "btn btn-success btn-sm btnImp" onClick="xajax_ModificarValidation('.$agente['id_validacion_edad'].')"  data-target="#exampleModal"  data-whatever="@mdo" data-toggle="modal" "data-dismiss="modal"><i class="">Editar</i>
                        </button>
                    </div>
                </td>         
            </tr>';
        }else{
             $html.= '<tr class = text-center>
                <td>'.$agente['id_validacion_edad'].'</td>
                <td style = "color: green;">'.$agente['d_status'].'</td>
                <td>'.$agente['edad_min_estudiante'].'</td>
                <td>'.$agente['edad_max_estudiante'].'</td>
                <td style="width: 10%;">
                    <div class="btn-group">
                        <button type="button" style = "box-shadow: 0px 9px 3px rgba(0,0,0,.2); font-family: "Lato";" class = "btn btn-success btn-sm btnImp" onClick="xajax_ModificarValidation('.$agente['id_validacion_edad'].')"  data-target="#exampleModal"  data-whatever="@mdo" data-toggle="modal" "data-dismiss="modal"><i class="">Editar</i>
                        </button>
                    </div>
                </td>         
            </tr>';        }
    }
    //var_dump($html);
    $obj->addAssign('hola', 'innerHTML', $html);
    $obj->addScript("datatable('grid');");
   return $obj;
}

function ModificarValidation($id_validacion_edadID){
    $obj = new xajaxResponse('UTF-8');
    $loginModel = new register_alumnoModel();
    $result = $loginModel->SearchValidationEdadById($id_validacion_edadID);
    $html = "";
    //var_dump($id_validacion_edad);

    for ($i=0; $i < $result['numRows']; $i++) { 
        $agente = pg_fetch_assoc($result['query'], $i);
       
        $id_validacion_edad = $agente['id_validacion_edad'];
        $obj->addAssign('id_validacion_edad', 'value', $id_validacion_edad);

        $html=
        "<div class = 'form-group'>
            <label for = 'message-text' class = 'col-form-label'>Fecha de Nacimiento Maxima</label>
            <input style = 'width: 320px;' type = 'text'  name = 'edad_min' class = 'form-control' id = 'edad_min' onBlur=validateField() value = '".$agente['edad_min_estudiante']."' maxlength = '4' minlength = '4' ></input>
                <p class= 'parrafo' id = 'parrafoNombre'></p>
        </div>

        <div style = 'margin-top: 70px;' class = 'form-group'>
            <label for = 'message-text' class = 'col-form-label'>Fecha de Nacimiento Minima</label>
            <input style = 'width: 320px;' type = 'text'  name = 'edad_max' class = 'form-control' id = 'edad_max' onBlur=validateField1() value = '".$agente['edad_max_estudiante']."'></input>
                <p class= 'parrafo' id = 'parrafoNombre'></p>
        </div> 

        <div class = 'form-group'>
            <label  style = 'margin-top: 50px; margin-left: 130px;' for = 'message-text' class = 'col-form-label'>Status</label>
            <select style = 'width: 120px; margin-top: 1px; margin-left: 95px;' type = 'select' class = 'form-select' name = 'status' id = 'status'>
                <option disabled hidden selected value = '".$agente['id_status']."'>".$agente['d_status']."</option>
                <option value = 1>Activo</option>
                <option value = 2>Inactivo</option>
            </select>
        </div>";
    }
  $obj->addScript("$(document).ready(function(){
    $.mask.definitions['~']='[VE]';
    $('#cedula').mask('~-9?9999999');
  });");
  $obj->addAssign('form', 'innerHTML', $html);
 return $obj;
}

function ShowEdadResta($value, $id_validacion_edad){
    $obj = new xajaxResponse('UTF-8');
    $model = new register_alumnoModel();
    $fecha_actual = date("Y");
    $edad_min = $result['row']['edad_min_estudiante'];
    $edad_max = $result['row']['edad_max_estudiante'];
    $fecha_input = $id_validacion_edad;
    
    $resta = $fecha_actual - $fecha_input;
      //var_dump($fecha_input);

    //var_dump($cedula_profesor);
    $obj->addAssign('edad', 'value', $resta);
    return $obj;  
}

function ShowEdadResta1($value, $id_validacion_edad1){
    $obj = new xajaxResponse('UTF-8');
    $model = new register_alumnoModel();
    $fecha_actual = date("Y");
    $edad_min = $result['row']['edad_min_estudiante'];
    $edad_max = $result['row']['edad_max_estudiante'];
    $fecha_input = $id_validacion_edad1;
    
    $resta = $fecha_actual - $fecha_input;
      //var_dump($fecha_input);

    //var_dump($cedula_profesor);
    $obj->addAssign('edad1', 'value', $resta);
    return $obj;  
}


function UpdateValidationInfo($form, $edad_min){
$obj = new xajaxResponse('UTF-8');
  $Model = new register_alumnoModel();
  $result = $Model->SearchValidationEdadById1($form);
  $html='';
  


  $int_fecha_min = intval($result['row']['edad_min_estudiante']);
  $int_fecha_max = intval($result['row']['edad_max_estudiante']);

  $anio = 1924;


    if($form['edad_min'] != ""){
    	if($form['edad_max'] != ""){
    		if(preg_match('/^\d{4}$/', $form['edad_min'])){
        		if(preg_match('/^\d{4}$/', $form['edad_max'])){
            		if($edad_min >= $anio){
                $result = $Model->UpdateValidationInfo($form);
                if($result){
                    $obj->addScript("Swal.fire({
                        title: '¡Se ha Actualizado!',
                        text: 'Los datos de la Materia se han Actualizado Correctamente.',
                        icon: 'success',
                        color: 'black'
                    });");  
                    //REDIRECTION
                    $obj->addScript("setTimeout(function(){ window.location='limitation_FechaNac';},1555)");
                    //
                }else{
                    $obj->addScript("Swal.fire({
                        title: '¡No se puede Actualizar!',
                        text: 'No se puede Actualizar, ha ocurrido un error.',
                        icon: 'warning',
                        color: 'black'
                    });");
                }
            }else{
            	$obj->addScript("Swal.fire({
                    title: '¡No se puede Actualizar!',
                    text: 'La Fecha de nacimiento Máxima no puede pasar de 1924.',
                    icon: 'error',
                    color: 'black'
                });"); 
            }
        }else{
            $obj->addScript("Swal.fire({
                title: '¡No se puede Registrar la Materia!',
                text: 'La materia No puede tener carácteres especiales, números ni acentos',
                icon: 'error',
                color: 'black'
            });");
        }
    }else{
        $obj->addScript("Swal.fire({
            title: '¡No se puede Actualizar!',
            text: 'La el campo fecha de nacimiento no puede contener letras.',
            icon: 'error',
            color: 'black'
        });");
    }
}else{
	$obj->addScript("Swal.fire({
            title: '¡No se puede Actualizar!',
            text: 'El campo Fecha Nacimiento Máxima está vacío.',
            icon: 'error',
            color: 'black'
        });");
}
}else{
	$obj->addScript("Swal.fire({
            title: '¡No se puede Actualizar!',
            text: 'El campo Fecha Nacimiento Mínima está vacío.',
            icon: 'error',
            color: 'black'
        });");
    
}
  return $obj;
}
 

  //registramos la función creada anteriormente al objeto xajax
  //$xajax->registerFunction("hora");
  $xajax->registerFunction("volver");
  $xajax->registerFunction("ShowEdadResta1");
  $xajax->registerFunction("ShowEdadResta");
  $xajax->registerFunction("showLimitacionEdad");
  $xajax->registerFunction("ModificarValidation");  
  $xajax->registerFunction("UpdateValidationInfo");

  //El objeto xajax tiene que procesar cualquier petición
  $xajax->processRequests();
?>