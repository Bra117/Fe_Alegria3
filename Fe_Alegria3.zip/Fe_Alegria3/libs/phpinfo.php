<?php
  phpinfo();
?>