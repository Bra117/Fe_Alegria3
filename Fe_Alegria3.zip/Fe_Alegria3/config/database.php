<?php
  //Conexion a la Base de Datos 

//
define("bd_hostname", '127.0.0.1');
define("mvc_port", '5432');
define("bd_usuario", 'postgres');
define("bd_clave", '30306741');
define("database", 'fe_y_alegria');
?>